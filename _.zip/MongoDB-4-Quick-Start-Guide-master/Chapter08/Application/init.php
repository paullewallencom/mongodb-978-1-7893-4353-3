<?php
// Chapter 8 _From Web Form to MongoDB_
// this file returns config params
// use this file if you want to demo with no security and no transactions

return [
    'uri' => [
        'host' => '127.0.0.1',
        'database' => 'sweetscomplete'
    ]
];
