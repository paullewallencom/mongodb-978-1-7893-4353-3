# Chapter 7 _Securing MongoDB_

To restore the sample database:
* Open a terminal window / command prompt
* Change to this directory
* Run this command:
```
mongorestore
```
