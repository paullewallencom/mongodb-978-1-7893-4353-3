<?php
$types[] = [
    'type' => 'Social Media',
    'options' => ['Facebook','Twitter','Instragram']
];
echo json_encode($types);
